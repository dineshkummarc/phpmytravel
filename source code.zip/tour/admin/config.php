<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tour1";

$currency = "INR";


date_default_timezone_set('Asia/Kolkata');





$smtp_host = 'smtp.gmail.com';
$smtp_user = 'yourmail@gmail.com';
$smtp_pass = 'EJWGDSDSIYIQNHVB';
