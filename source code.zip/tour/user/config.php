<?php
//database settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tour1";

$currency = "INR";


date_default_timezone_set('Asia/Kolkata');

//Installation - Include the last slash
$instalation_dir = "http://localhost/travels/";

//Mail settings
$smtp_host = 'smtp.gmail.com';
$smtp_user = 'travel@gmail.com';
$smtp_pass = 'EJWGVR2020QNHVB';
